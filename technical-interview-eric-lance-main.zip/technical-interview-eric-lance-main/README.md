Take-Home Test Project
This project is designed to showcase your skills and knowledge in software development. It includes a sample application that demonstrates your ability to write clean, efficient, and maintainable code.

Installation 

To get started with this project, follow these steps:
~Fork repository
~Clone the repository

Read and follow directions in the Technical Interview Designs document included in this project.
When ready, create 1 merge request into main with your changes.