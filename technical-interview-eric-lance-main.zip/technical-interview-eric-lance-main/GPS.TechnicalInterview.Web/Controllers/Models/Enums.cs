﻿namespace GPS.ApplicationManager.Web.Controllers.Models
{
  public enum ApplicationStatus
  {
    New = 0,
    Approved = 1,
    Funded = 2
  }
}
